NEWPIXEL — ربط نموذج تقديم الإدارة بديسكورد بأمان

مهم: لا تضع رابط Webhook داخل index.html أو أي ملف داخل assets. الرابط السري يوضع فقط في إعدادات الاستضافة كـ Secret.

الطريقة الموصى بها: Cloudflare Pages
1) ادخل https://dash.cloudflare.com/ وأنشئ حساباً إن لم يكن لديك.
2) افتح Workers & Pages ثم Create application ثم Pages.
3) ارفع مجلد newpixel-site (المجلد الذي يحتوي index.html و assets و functions) عبر طريقة Direct Upload إن كانت متاحة في واجهتك. يجب أن تكون index.html في جذر المشروع، وfunctions/api/apply.js داخل مجلد functions.
4) بعد النشر افتح مشروع Pages ثم Settings > Variables and Secrets.
5) أضف متغيراً سرياً باسم DISCORD_WEBHOOK_URL والصق فيه رابط Webhook. اختر نوع Secret إذا ظهر خيار النوع.
6) أضف متغيراً باسم SITE_ORIGIN وقيمته عنوان الموقع المنشور بالكامل، مثال: https://اسم-المشروع.pages.dev (بدون / في النهاية).
7) أعد نشر الموقع إذا طلبت Cloudflare ذلك، ثم اختبر نموذج تقديم الإدارة بطلب تجريبي.

ملاحظة: لا تشارك رابط Webhook مع أي شخص، ولا ترسله في محادثة أو تضعه في ملف HTML. إذا انكشف الرابط، احذفه/أعد توليده من Discord Integrations > Webhooks.

إذا كان موقعك مستضافاً على خدمة أخرى، لا ترفع هذه الملفات كما هي وتتوقع أن تعمل وظائف Pages؛ أخبرنا باسم الاستضافة لنجهز طريقة مناسبة لها.

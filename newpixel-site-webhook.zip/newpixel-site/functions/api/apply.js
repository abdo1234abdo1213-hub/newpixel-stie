export async function onRequestPost({ request, env }) {
  const origin = request.headers.get('Origin');
  const allowedOrigin = env.SITE_ORIGIN;
  if (!env.DISCORD_WEBHOOK_URL) {
    return json({ error: 'الخدمة غير مجهزة بعد.' }, 503);
  }
  if (allowedOrigin && origin && origin !== allowedOrigin) {
    return json({ error: 'طلب غير مسموح.' }, 403);
  }
  let data;
  try { data = await request.json(); }
  catch { return json({ error: 'بيانات الطلب غير صحيحة.' }, 400); }

  // Honeypot field for simple bot/spam filtering.
  if (String(data.website || '').trim()) return json({ ok: true });

  const name = clean(data.name, 80);
  const discord = clean(data.discord, 80);
  const age = Number(data.age);
  const hours = clean(data.hours, 40);
  const experience = clean(data.experience, 900);
  const reason = clean(data.reason, 900);
  if (!name || !discord || !Number.isInteger(age) || age < 13 || age > 99 || !hours || !experience || !reason) {
    return json({ error: 'راجع كل الخانات وحاول مرة ثانية.' }, 400);
  }

  const embed = {
    title: 'طلب تقديم إدارة جديد — NEWPIXEL',
    color: 0xC7C7CC,
    fields: [
      { name: 'الاسم', value: name },
      { name: 'اسم الديسكورد', value: discord },
      { name: 'العمر', value: String(age), inline: true },
      { name: 'النشاط اليومي', value: hours, inline: true },
      { name: 'الخبرة السابقة', value: experience },
      { name: 'سبب التقديم', value: reason }
    ],
    footer: { text: 'NEWPIXEL • نموذج تقديم الإدارة' },
    timestamp: new Date().toISOString()
  };

  let response;
  try {
    response = await fetch(env.DISCORD_WEBHOOK_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ embeds: [embed], allowed_mentions: { parse: [] } })
    });
  } catch {
    return json({ error: 'تعذر الاتصال بديسكورد. حاول لاحقاً.' }, 502);
  }
  if (!response.ok) return json({ error: 'تعذر إرسال الطلب إلى ديسكورد. راجع إعدادات الربط.' }, 502);
  return json({ ok: true });
}

export async function onRequestOptions({ request, env }) {
  const origin = request.headers.get('Origin');
  const allowedOrigin = env.SITE_ORIGIN;
  if (allowedOrigin && origin && origin !== allowedOrigin) return new Response(null, { status: 403 });
  return new Response(null, { status: 204, headers: corsHeaders(origin, allowedOrigin) });
}

function clean(value, max) {
  return String(value ?? '').replace(/[\u0000-\u001F\u007F]/g, ' ').trim().slice(0, max);
}
function corsHeaders(origin, allowedOrigin) {
  const headers = new Headers({ 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type', 'Vary': 'Origin' });
  if (origin && (!allowedOrigin || origin === allowedOrigin)) headers.set('Access-Control-Allow-Origin', origin);
  return headers;
}
function json(body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' } });
}
